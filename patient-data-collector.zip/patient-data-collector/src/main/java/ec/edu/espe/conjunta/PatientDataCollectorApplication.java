package ec.edu.espe.conjunta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientDataCollectorApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientDataCollectorApplication.class, args);
	}

}
