package ec.edu.espe.conjunta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthAnalyzerApplicationTests {

	@Test
	void contextLoads() {
	}

}
