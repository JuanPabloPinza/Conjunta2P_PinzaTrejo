package ec.edu.espe.conjunta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthAnalyzerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthAnalyzerApplication.class, args);
	}

}
