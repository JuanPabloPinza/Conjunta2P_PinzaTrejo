package ec.edu.espe.conjunta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareNotifierApplication {

	public static void main(String[] args) {
		SpringApplication.run(CareNotifierApplication.class, args);
	}

}
